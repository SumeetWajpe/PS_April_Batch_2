import { Add, Point } from "./module";
console.log(`The addition is ${Add(20, 50)}`);
var pt = new Point(20, 30);
console.log(`[X:${pt.x},Y:${pt.y}]`);
