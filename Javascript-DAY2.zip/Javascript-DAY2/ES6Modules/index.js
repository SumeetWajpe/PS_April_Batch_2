import * as MathModule from "./math.js";

console.log("The addition is : " + MathModule.default(60, 30));
console.log("The multiplication is : " + MathModule.Product(60, 30));

// import Addition, { Product } from "./math.js";
// console.log("The addition is : " + Addition(60, 30));
// console.log("The multiplication is : " + Product(60, 30));
